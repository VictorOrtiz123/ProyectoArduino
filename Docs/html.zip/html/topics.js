var topics =
[
    [ "Pines LED RGB (catodo comun)", "group__pines__led.html", "group__pines__led" ],
    [ "Pines de actuadores", "group__pines__actuadores.html", "group__pines__actuadores" ],
    [ "Pines analogicos de sensores", "group__pines__sensores.html", "group__pines__sensores" ],
    [ "Pines RFID RC522 (SPI)", "group__pines__rfid.html", "group__pines__rfid" ],
    [ "Modulo de reloj", "group__modulo__reloj.html", "group__modulo__reloj" ],
    [ "Mapa de direcciones EEPROM", "group__eeprom__map.html", "group__eeprom__map" ]
];