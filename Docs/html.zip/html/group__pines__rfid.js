var group__pines__rfid =
[
    [ "RST_PIN", "group__pines__rfid.html#ga36932b0e869e0114f32e255f61306d6b", null ],
    [ "SS_PIN", "group__pines__rfid.html#ga86fac98c9b4c98a3e50fc45440878391", null ]
];