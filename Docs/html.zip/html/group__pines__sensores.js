var group__pines__sensores =
[
    [ "PIN_HALL", "group__pines__sensores.html#ga9c80d45f4c5f9729887dcd301a26a342", null ],
    [ "PIN_LUZ", "group__pines__sensores.html#ga456010749e02571badfd3c3741165fd8", null ],
    [ "PIN_SONIDO", "group__pines__sensores.html#ga220ac65470e685e9ccba1658fb511cc0", null ],
    [ "PIN_TEMP", "group__pines__sensores.html#ga65292d0ee3521543804b71d6726f162d", null ]
];