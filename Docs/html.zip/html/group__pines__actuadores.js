var group__pines__actuadores =
[
    [ "PIN_BUZZER", "group__pines__actuadores.html#ga192ea8eaba652d29bfc08675edebb6a2", null ],
    [ "PIN_SERVO", "group__pines__actuadores.html#ga683a2f1ac846d9e7c7f68fd29130ee1a", null ]
];