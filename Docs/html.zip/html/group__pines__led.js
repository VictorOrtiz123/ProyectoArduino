var group__pines__led =
[
    [ "PIN_B", "group__pines__led.html#ga9fda21ec50fc75d0fa9bbcb33bf560ff", null ],
    [ "PIN_G", "group__pines__led.html#ga0ad7f19ed019c092e1c003afc15a7881", null ],
    [ "PIN_R", "group__pines__led.html#gaef9efdab3ba730a39577a8efcb282fb8", null ]
];