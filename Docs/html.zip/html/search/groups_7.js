var searchData=
[
  ['rc522_20spi_0',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]],
  ['reloj_1',['Modulo de reloj',['../group__modulo__reloj.html',1,'']]],
  ['rfid_20rc522_20spi_2',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]],
  ['rgb_20catodo_20comun_3',['Pines LED RGB (catodo comun)',['../group__pines__led.html',1,'']]]
];
