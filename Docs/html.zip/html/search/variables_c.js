var searchData=
[
  ['rolactivo_0',['rolActivo',['../sistema__acceso__doxygen_8cpp.html#a64ee9f24a20f85cc12920cdb58ea0c3d',1,'sistema_acceso_doxygen.cpp']]],
  ['rolcambio_1',['rolCambio',['../sistema__acceso__doxygen_8cpp.html#a4fb5572f55643df444f10a65c87dfb0f',1,'sistema_acceso_doxygen.cpp']]],
  ['rolhorario_2',['rolHorario',['../sistema__acceso__doxygen_8cpp.html#aa3636d2dfb36f0e90ed9f5f55317e1ff',1,'sistema_acceso_doxygen.cpp']]],
  ['rolhorariotxt_3',['rolHorarioTxt',['../sistema__acceso__doxygen_8cpp.html#a2105a058f170ad490eee41b2b2bb229d',1,'sistema_acceso_doxygen.cpp']]],
  ['rolnombre_4',['rolNombre',['../sistema__acceso__doxygen_8cpp.html#aa25230185f800188f44dc661f6c1b9d6',1,'sistema_acceso_doxygen.cpp']]]
];
