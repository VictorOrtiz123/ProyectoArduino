var searchData=
[
  ['de_20actuadores_0',['Pines de actuadores',['../group__pines__actuadores.html',1,'']]],
  ['de_20direcciones_20eeprom_1',['Mapa de direcciones EEPROM',['../group__eeprom__map.html',1,'']]],
  ['de_20reloj_2',['Modulo de reloj',['../group__modulo__reloj.html',1,'']]],
  ['de_20sensores_3',['Pines analogicos de sensores',['../group__pines__sensores.html',1,'']]],
  ['direcciones_20eeprom_4',['Mapa de direcciones EEPROM',['../group__eeprom__map.html',1,'']]]
];
