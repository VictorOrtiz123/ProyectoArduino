var searchData=
[
  ['actuadores_0',['Pines de actuadores',['../group__pines__actuadores.html',1,'']]],
  ['analogicos_20de_20sensores_1',['Pines analogicos de sensores',['../group__pines__sensores.html',1,'']]]
];
