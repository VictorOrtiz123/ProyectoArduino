var searchData=
[
  ['rc522_20spi_0',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]],
  ['reloj_1',['Modulo de reloj',['../group__modulo__reloj.html',1,'']]],
  ['relojactual_2',['relojActual',['../group__modulo__reloj.html#ga4f5f8b8175ce3ad524673fe589a65fca',1,'sistema_acceso_doxygen.cpp']]],
  ['resetbuffer_3',['resetBuffer',['../sistema__acceso__doxygen_8cpp.html#a8765f1344e57db0a3e0c798c9ac6a1fe',1,'sistema_acceso_doxygen.cpp']]],
  ['rfid_20rc522_20spi_4',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]],
  ['rgb_20catodo_20comun_5',['Pines LED RGB (catodo comun)',['../group__pines__led.html',1,'']]],
  ['rolactivo_6',['rolActivo',['../sistema__acceso__doxygen_8cpp.html#a64ee9f24a20f85cc12920cdb58ea0c3d',1,'sistema_acceso_doxygen.cpp']]],
  ['rolcambio_7',['rolCambio',['../sistema__acceso__doxygen_8cpp.html#a4fb5572f55643df444f10a65c87dfb0f',1,'sistema_acceso_doxygen.cpp']]],
  ['rolhorario_8',['rolHorario',['../sistema__acceso__doxygen_8cpp.html#aa3636d2dfb36f0e90ed9f5f55317e1ff',1,'sistema_acceso_doxygen.cpp']]],
  ['rolhorariotxt_9',['rolHorarioTxt',['../sistema__acceso__doxygen_8cpp.html#a2105a058f170ad490eee41b2b2bb229d',1,'sistema_acceso_doxygen.cpp']]],
  ['rolnombre_10',['rolNombre',['../sistema__acceso__doxygen_8cpp.html#aa25230185f800188f44dc661f6c1b9d6',1,'sistema_acceso_doxygen.cpp']]],
  ['rst_5fpin_11',['RST_PIN',['../group__pines__rfid.html#ga36932b0e869e0114f32e255f61306d6b',1,'sistema_acceso_doxygen.cpp']]]
];
