var searchData=
[
  ['largo_5fclave_0',['LARGO_CLAVE',['../sistema__acceso__doxygen_8cpp.html#aeb528f7b260670e4c8d564973f71ae5b',1,'sistema_acceso_doxygen.cpp']]],
  ['largo_5ftarjeta_1',['LARGO_TARJETA',['../sistema__acceso__doxygen_8cpp.html#a18a9efba988f6ba89a7525c124500fd9',1,'sistema_acceso_doxygen.cpp']]],
  ['ledrojoestado_2',['ledRojoEstado',['../sistema__acceso__doxygen_8cpp.html#a5828ea72f86501600403707439158ebb',1,'sistema_acceso_doxygen.cpp']]],
  ['longbuffer_3',['longBuffer',['../sistema__acceso__doxygen_8cpp.html#ab5f80987f6da87002a609199514aa0b9',1,'sistema_acceso_doxygen.cpp']]],
  ['longgestion_4',['longGestion',['../sistema__acceso__doxygen_8cpp.html#a295e8d65fee91cbce7e4c1d26d403093',1,'sistema_acceso_doxygen.cpp']]]
];
