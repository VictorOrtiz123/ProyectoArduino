var searchData=
[
  ['botonestable_0',['botonEstable',['../sistema__acceso__doxygen_8cpp.html#aea9f9ef410f9349f1fc4060910a888c2',1,'sistema_acceso_doxygen.cpp']]],
  ['botonlecturaprev_1',['botonLecturaPrev',['../sistema__acceso__doxygen_8cpp.html#abf22a9c09bf4b80af84b64227764a64c',1,'sistema_acceso_doxygen.cpp']]],
  ['bufferclave_2',['bufferClave',['../sistema__acceso__doxygen_8cpp.html#a22a4617978e8ec977ab29580e8e48216',1,'sistema_acceso_doxygen.cpp']]],
  ['buffergestion_3',['bufferGestion',['../sistema__acceso__doxygen_8cpp.html#a95701abdf9df4ad9c7c16da3d18999d6',1,'sistema_acceso_doxygen.cpp']]]
];
