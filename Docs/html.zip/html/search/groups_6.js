var searchData=
[
  ['pines_20analogicos_20de_20sensores_0',['Pines analogicos de sensores',['../group__pines__sensores.html',1,'']]],
  ['pines_20de_20actuadores_1',['Pines de actuadores',['../group__pines__actuadores.html',1,'']]],
  ['pines_20led_20rgb_20catodo_20comun_2',['Pines LED RGB (catodo comun)',['../group__pines__led.html',1,'']]],
  ['pines_20rfid_20rc522_20spi_3',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]]
];
