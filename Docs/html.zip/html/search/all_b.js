var searchData=
[
  ['num_5froles_0',['NUM_ROLES',['../sistema__acceso__doxygen_8cpp.html#a5b7d4cc1a64426fb87404fba567c2a47',1,'sistema_acceso_doxygen.cpp']]]
];
