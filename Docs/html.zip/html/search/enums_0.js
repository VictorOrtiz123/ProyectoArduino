var searchData=
[
  ['causaerror_0',['CausaError',['../sistema__acceso__doxygen_8cpp.html#a1b60d20eda3179504e19f59bcd0ab976',1,'sistema_acceso_doxygen.cpp']]]
];
