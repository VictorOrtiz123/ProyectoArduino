var searchData=
[
  ['valorsensor_0',['valorSensor',['../sistema__acceso__doxygen_8cpp.html#ae0a7db2e726e24c16cce804d6a95f481',1,'sistema_acceso_doxygen.cpp']]],
  ['verificarclave_1',['verificarClave',['../sistema__acceso__doxygen_8cpp.html#ae97e84012a0dd4bd6035ba3b1266febd',1,'sistema_acceso_doxygen.cpp']]]
];
