var searchData=
[
  ['tipogestion_0',['TipoGestion',['../sistema__acceso__doxygen_8cpp.html#a62d8bd7b2646a973727808baa399c00c',1,'sistema_acceso_doxygen.cpp']]]
];
