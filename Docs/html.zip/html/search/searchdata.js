var indexSectionsWithContent =
{
  0: "abcdefghilmnprstuv",
  1: "s",
  2: "acegilmprstv",
  3: "bcdefghilmnprstuv",
  4: "cest",
  5: "egs",
  6: "p",
  7: "acdelmprs"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues",
  6: "defines",
  7: "groups"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Variables",
  4: "Enumerations",
  5: "Enumerator",
  6: "Macros",
  7: "Modules"
};

