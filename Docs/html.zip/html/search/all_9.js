var searchData=
[
  ['largo_5fclave_0',['LARGO_CLAVE',['../sistema__acceso__doxygen_8cpp.html#aeb528f7b260670e4c8d564973f71ae5b',1,'sistema_acceso_doxygen.cpp']]],
  ['largo_5ftarjeta_1',['LARGO_TARJETA',['../sistema__acceso__doxygen_8cpp.html#a18a9efba988f6ba89a7525c124500fd9',1,'sistema_acceso_doxygen.cpp']]],
  ['lcd_2',['lcd',['../sistema__acceso__doxygen_8cpp.html#af97afdf00af0e116e9b5957f6a470fc2',1,'sistema_acceso_doxygen.cpp']]],
  ['led_20rgb_20catodo_20comun_3',['Pines LED RGB (catodo comun)',['../group__pines__led.html',1,'']]],
  ['ledcolor_4',['ledColor',['../sistema__acceso__doxygen_8cpp.html#a0e480616f133e1a145550439743eadae',1,'sistema_acceso_doxygen.cpp']]],
  ['ledrojoestado_5',['ledRojoEstado',['../sistema__acceso__doxygen_8cpp.html#a5828ea72f86501600403707439158ebb',1,'sistema_acceso_doxygen.cpp']]],
  ['longbuffer_6',['longBuffer',['../sistema__acceso__doxygen_8cpp.html#ab5f80987f6da87002a609199514aa0b9',1,'sistema_acceso_doxygen.cpp']]],
  ['longgestion_7',['longGestion',['../sistema__acceso__doxygen_8cpp.html#a295e8d65fee91cbce7e4c1d26d403093',1,'sistema_acceso_doxygen.cpp']]],
  ['loop_8',['loop',['../sistema__acceso__doxygen_8cpp.html#afe461d27b9c48d5921c00d521181f12f',1,'sistema_acceso_doxygen.cpp']]]
];
