var searchData=
[
  ['relojactual_0',['relojActual',['../group__modulo__reloj.html#ga4f5f8b8175ce3ad524673fe589a65fca',1,'sistema_acceso_doxygen.cpp']]],
  ['resetbuffer_1',['resetBuffer',['../sistema__acceso__doxygen_8cpp.html#a8765f1344e57db0a3e0c798c9ac6a1fe',1,'sistema_acceso_doxygen.cpp']]]
];
