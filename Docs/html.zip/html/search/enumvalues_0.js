var searchData=
[
  ['err_5fclave_0',['ERR_CLAVE',['../sistema__acceso__doxygen_8cpp.html#a1b60d20eda3179504e19f59bcd0ab976a4641661ec79f9e62a54c1265a0e4ac12',1,'sistema_acceso_doxygen.cpp']]],
  ['err_5fhorario_1',['ERR_HORARIO',['../sistema__acceso__doxygen_8cpp.html#a1b60d20eda3179504e19f59bcd0ab976a6c5d360915b1ab603f87f43bf6c2f301',1,'sistema_acceso_doxygen.cpp']]],
  ['err_5ftarjeta_2',['ERR_TARJETA',['../sistema__acceso__doxygen_8cpp.html#a1b60d20eda3179504e19f59bcd0ab976abc63c75d9511272154da0b77d7f1dc7b',1,'sistema_acceso_doxygen.cpp']]]
];
