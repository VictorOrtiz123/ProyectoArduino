var searchData=
[
  ['paso_5fmonitor_0',['PASO_MONITOR',['../sistema__acceso__doxygen_8cpp.html#a94f611687c68c33c3590dda49d9b554d',1,'sistema_acceso_doxygen.cpp']]],
  ['pasogestionumbral_1',['pasoGestionUmbral',['../sistema__acceso__doxygen_8cpp.html#ab9268c1226c1b7f8c4a2794844748266',1,'sistema_acceso_doxygen.cpp']]],
  ['pendientecambio_2',['pendienteCambio',['../sistema__acceso__doxygen_8cpp.html#a3d5a1db0f57cc9f602610f3d15f5bba6',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fb_3',['PIN_B',['../group__pines__led.html#ga9fda21ec50fc75d0fa9bbcb33bf560ff',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fboton_5fconfig_4',['PIN_BOTON_CONFIG',['../sistema__acceso__doxygen_8cpp.html#ace9fc21acbefaa4abbef11cf5bf0e0fd',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fbuzzer_5',['PIN_BUZZER',['../group__pines__actuadores.html#ga192ea8eaba652d29bfc08675edebb6a2',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fg_6',['PIN_G',['../group__pines__led.html#ga0ad7f19ed019c092e1c003afc15a7881',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fhall_7',['PIN_HALL',['../group__pines__sensores.html#ga9c80d45f4c5f9729887dcd301a26a342',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fluz_8',['PIN_LUZ',['../group__pines__sensores.html#ga456010749e02571badfd3c3741165fd8',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fr_9',['PIN_R',['../group__pines__led.html#gaef9efdab3ba730a39577a8efcb282fb8',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fservo_10',['PIN_SERVO',['../group__pines__actuadores.html#ga683a2f1ac846d9e7c7f68fd29130ee1a',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5fsonido_11',['PIN_SONIDO',['../group__pines__sensores.html#ga220ac65470e685e9ccba1658fb511cc0',1,'sistema_acceso_doxygen.cpp']]],
  ['pin_5ftemp_12',['PIN_TEMP',['../group__pines__sensores.html#ga65292d0ee3521543804b71d6726f162d',1,'sistema_acceso_doxygen.cpp']]],
  ['pines_20analogicos_20de_20sensores_13',['Pines analogicos de sensores',['../group__pines__sensores.html',1,'']]],
  ['pines_20de_20actuadores_14',['Pines de actuadores',['../group__pines__actuadores.html',1,'']]],
  ['pines_20led_20rgb_20catodo_20comun_15',['Pines LED RGB (catodo comun)',['../group__pines__led.html',1,'']]],
  ['pines_20rfid_20rc522_20spi_16',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]],
  ['pinescols_17',['pinesCols',['../sistema__acceso__doxygen_8cpp.html#acd420422c09928dc34bfd70c75217822',1,'sistema_acceso_doxygen.cpp']]],
  ['pinesfilas_18',['pinesFilas',['../sistema__acceso__doxygen_8cpp.html#ad243ec4d9e9fedf0e5b1157d35620176',1,'sistema_acceso_doxygen.cpp']]],
  ['procesartarjeta_19',['procesarTarjeta',['../sistema__acceso__doxygen_8cpp.html#ab71169b9b016d53ef41f6d94d282df65',1,'sistema_acceso_doxygen.cpp']]]
];
