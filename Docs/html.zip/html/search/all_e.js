var searchData=
[
  ['s_5fhall_0',['S_HALL',['../sistema__acceso__doxygen_8cpp.html#a9628766e5f200cc84b296b071b09ff4aafe80412ab2c4742c6b2e256f2d80443e',1,'sistema_acceso_doxygen.cpp']]],
  ['s_5fluz_1',['S_LUZ',['../sistema__acceso__doxygen_8cpp.html#a9628766e5f200cc84b296b071b09ff4aaaf2d80757e1a73fb939794ed2d1411b5',1,'sistema_acceso_doxygen.cpp']]],
  ['s_5fsonido_2',['S_SONIDO',['../sistema__acceso__doxygen_8cpp.html#a9628766e5f200cc84b296b071b09ff4aa04658eaeb107961596ae4bc72f65e7b9',1,'sistema_acceso_doxygen.cpp']]],
  ['s_5ftemp_3',['S_TEMP',['../sistema__acceso__doxygen_8cpp.html#a9628766e5f200cc84b296b071b09ff4aa89c444c1deadc19fba14562be5bec663',1,'sistema_acceso_doxygen.cpp']]],
  ['sensor_4',['Sensor',['../sistema__acceso__doxygen_8cpp.html#a9628766e5f200cc84b296b071b09ff4a',1,'sistema_acceso_doxygen.cpp']]],
  ['sensores_5',['Pines analogicos de sensores',['../group__pines__sensores.html',1,'']]],
  ['servo_5fabierto_6',['SERVO_ABIERTO',['../sistema__acceso__doxygen_8cpp.html#aa75ab7db2b52c489bc36080ef483e4c6',1,'sistema_acceso_doxygen.cpp']]],
  ['servo_5fcerrado_7',['SERVO_CERRADO',['../sistema__acceso__doxygen_8cpp.html#a500aa64f860d437b72b4b436e09a1c9e',1,'sistema_acceso_doxygen.cpp']]],
  ['servocerradura_8',['servoCerradura',['../sistema__acceso__doxygen_8cpp.html#af1d5fe095acd6d9321fd37841b38bfd9',1,'sistema_acceso_doxygen.cpp']]],
  ['servoestaabierto_9',['servoEstaAbierto',['../sistema__acceso__doxygen_8cpp.html#a60780114a86ac8c791ad56684159888b',1,'sistema_acceso_doxygen.cpp']]],
  ['setup_10',['setup',['../sistema__acceso__doxygen_8cpp.html#a4fc01d736fe50cf5b977f755b675f11d',1,'sistema_acceso_doxygen.cpp']]],
  ['sistema_5facceso_5fdoxygen_2ecpp_11',['sistema_acceso_doxygen.cpp',['../sistema__acceso__doxygen_8cpp.html',1,'']]],
  ['spi_12',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]],
  ['ss_5fpin_13',['SS_PIN',['../group__pines__rfid.html#ga86fac98c9b4c98a3e50fc45440878391',1,'sistema_acceso_doxygen.cpp']]],
  ['st_5fabierto_14',['ST_ABIERTO',['../sistema__acceso__doxygen_8cpp.html#a21966b54989cd66c32b522ac6958991da4a64142f000a9082ed3b84a8177ecfdf',1,'sistema_acceso_doxygen.cpp']]],
  ['st_5falarma_5fsensor_15',['ST_ALARMA_SENSOR',['../sistema__acceso__doxygen_8cpp.html#a21966b54989cd66c32b522ac6958991dacd3755dba11d466ffb1ad758a16feafd',1,'sistema_acceso_doxygen.cpp']]],
  ['st_5fbloqueado_16',['ST_BLOQUEADO',['../sistema__acceso__doxygen_8cpp.html#a21966b54989cd66c32b522ac6958991da6e406b7f97077d4486416222a75ee5cc',1,'sistema_acceso_doxygen.cpp']]],
  ['st_5ferror_5fcorto_17',['ST_ERROR_CORTO',['../sistema__acceso__doxygen_8cpp.html#a21966b54989cd66c32b522ac6958991da45e0a9f065e48ef15abcaf9f83635df7',1,'sistema_acceso_doxygen.cpp']]],
  ['st_5fgestion_18',['ST_GESTION',['../sistema__acceso__doxygen_8cpp.html#a21966b54989cd66c32b522ac6958991daa5ec3f3153d431f65168ec373f3f9f89',1,'sistema_acceso_doxygen.cpp']]],
  ['st_5finicio_19',['ST_INICIO',['../sistema__acceso__doxygen_8cpp.html#a21966b54989cd66c32b522ac6958991da747a8f3380ac53cbfa4201c80c4f92fb',1,'sistema_acceso_doxygen.cpp']]],
  ['st_5fmonitoreo_20',['ST_MONITOREO',['../sistema__acceso__doxygen_8cpp.html#a21966b54989cd66c32b522ac6958991da7461bf2ae6082fb173859d824f054df2',1,'sistema_acceso_doxygen.cpp']]]
];
