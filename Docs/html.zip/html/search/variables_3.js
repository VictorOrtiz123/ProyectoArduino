var searchData=
[
  ['estado_0',['estado',['../sistema__acceso__doxygen_8cpp.html#a071a88b455522218d2b1d3270c54a0aa',1,'sistema_acceso_doxygen.cpp']]]
];
