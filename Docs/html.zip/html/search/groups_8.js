var searchData=
[
  ['sensores_0',['Pines analogicos de sensores',['../group__pines__sensores.html',1,'']]],
  ['spi_1',['Pines RFID RC522 (SPI)',['../group__pines__rfid.html',1,'']]]
];
