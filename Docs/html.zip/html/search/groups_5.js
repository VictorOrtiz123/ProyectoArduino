var searchData=
[
  ['mapa_20de_20direcciones_20eeprom_0',['Mapa de direcciones EEPROM',['../group__eeprom__map.html',1,'']]],
  ['modulo_20de_20reloj_1',['Modulo de reloj',['../group__modulo__reloj.html',1,'']]]
];
