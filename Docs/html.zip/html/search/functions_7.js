var searchData=
[
  ['procesartarjeta_0',['procesarTarjeta',['../sistema__acceso__doxygen_8cpp.html#ab71169b9b016d53ef41f6d94d282df65',1,'sistema_acceso_doxygen.cpp']]]
];
