var searchData=
[
  ['paso_5fmonitor_0',['PASO_MONITOR',['../sistema__acceso__doxygen_8cpp.html#a94f611687c68c33c3590dda49d9b554d',1,'sistema_acceso_doxygen.cpp']]],
  ['pasogestionumbral_1',['pasoGestionUmbral',['../sistema__acceso__doxygen_8cpp.html#ab9268c1226c1b7f8c4a2794844748266',1,'sistema_acceso_doxygen.cpp']]],
  ['pendientecambio_2',['pendienteCambio',['../sistema__acceso__doxygen_8cpp.html#a3d5a1db0f57cc9f602610f3d15f5bba6',1,'sistema_acceso_doxygen.cpp']]],
  ['pinescols_3',['pinesCols',['../sistema__acceso__doxygen_8cpp.html#acd420422c09928dc34bfd70c75217822',1,'sistema_acceso_doxygen.cpp']]],
  ['pinesfilas_4',['pinesFilas',['../sistema__acceso__doxygen_8cpp.html#ad243ec4d9e9fedf0e5b1157d35620176',1,'sistema_acceso_doxygen.cpp']]]
];
