var group__modulo__reloj =
[
    [ "relojActual", "group__modulo__reloj.html#ga4f5f8b8175ce3ad524673fe589a65fca", null ],
    [ "tiempoCumplido", "group__modulo__reloj.html#ga517082b8325f6414771b50e522360fd1", null ],
    [ "tiempoTranscurrido", "group__modulo__reloj.html#gad167da1d9d78c5920a69aafe2ea5633d", null ]
];