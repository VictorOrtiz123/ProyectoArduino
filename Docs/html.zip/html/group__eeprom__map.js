var group__eeprom__map =
[
    [ "EE_CLAVES", "group__eeprom__map.html#ga7fd270b55a51964a9fadf14ed33e310b", null ],
    [ "EE_MAGIC", "group__eeprom__map.html#ga1fd4ad13f2b84340f09cc2753ff9c92d", null ],
    [ "EE_MAGIC_VAL", "group__eeprom__map.html#gaa1c904fef35924ac71b88d016800ceb5", null ],
    [ "EE_TARJETAS", "group__eeprom__map.html#ga231e6a59960664ab9041910e318ddd3f", null ],
    [ "EE_UMBRAL", "group__eeprom__map.html#gab3aa685c934c1ea07210cf333ae95368", null ]
];